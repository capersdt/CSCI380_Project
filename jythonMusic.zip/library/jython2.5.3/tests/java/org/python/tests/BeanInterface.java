package org.python.tests;


public interface BeanInterface extends Cloneable {
    String getName();
}
