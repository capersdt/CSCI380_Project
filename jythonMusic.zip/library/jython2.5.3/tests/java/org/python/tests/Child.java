package org.python.tests;

public class Child extends Parent {

    public void setId(int newId) {
        this.id = newId;
    }

    public String getValue() {
        return value;
    }
}
