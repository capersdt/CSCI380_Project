package org.python.tests.mro;


public interface SecondAndFirst extends SecondPredefinedGetitem, FirstPredefinedGetitem {}
