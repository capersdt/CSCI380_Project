package org.python.tests;

public class Parent {

    protected String value = "blah";

    protected int id = 7;

    public int getId() {
        return id;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
