package org.python.tests;


public class BeanImplementation implements BeanInterface {

    public String getName() {
        return "name";
    }
}
