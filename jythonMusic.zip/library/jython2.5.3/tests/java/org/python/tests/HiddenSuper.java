package org.python.tests;

public class HiddenSuper extends Bar {}

class Bar {

    public String hi() {
        return "hi";
    }
}