package org.python.jsr223;

public interface PythonCallable {
    String getAString();
    void callAVoid();
}
