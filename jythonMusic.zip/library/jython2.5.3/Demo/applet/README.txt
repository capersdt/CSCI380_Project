Applets do not work with the Jython 2.5.x branch due to the removal of the jythonc compiler.  Please visit the Jython book for the most up-to-date documentation on creating applets in Jython.

http://www.jythonbook.com

